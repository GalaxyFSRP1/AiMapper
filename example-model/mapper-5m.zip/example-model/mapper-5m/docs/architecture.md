# mapper-5m — architecture

Generated from `config.json` by AiMapper Model Studio.

- **Type**: decoder-only transformer, pre-LayerNorm, GELU MLP, tied embeddings
- **Depth**: 5 blocks
- **Width**: 336 (4 heads of 84)
- **FFN**: 672 (ratio 2.00×)
- **Context**: 512
- **Parameters**: 5,000,016

## Tensor groups

- `token_embedding` [872,336] — 292,992 params
- `position_embedding` [512,336] — 172,032 params
- `block0.ln_1` [336] — 672 params
- `block0.attn.qkv` [336,1008] — 339,696 params
- `block0.attn.proj` [336,336] — 113,232 params
- `block0.ln_2` [336] — 672 params
- `block0.mlp.in` [672,336] — 226,464 params
- `block0.mlp.out` [336,672] — 226,128 params
- `block1.ln_1` [336] — 672 params
- `block1.attn.qkv` [336,1008] — 339,696 params
- `block1.attn.proj` [336,336] — 113,232 params
- `block1.ln_2` [336] — 672 params
- … 3 more identical blocks …

See `weights/tensor_manifest.json` for the full per-tensor manifest.
